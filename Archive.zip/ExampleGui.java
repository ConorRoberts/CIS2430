
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class ExampleGui extends JFrame
{
	
	private NotAGame myC;

	public static final int WIDTH = 600;
	public static final int HEIGHT = 500;
	Container contentPane;
	TextField modelText;

	public ExampleGui(NotAGame c)
	{
		super();
		myC = c;
		setUpSize();
		setMainContainer();

	}

	private void setUpSize(){

		setSize(WIDTH, HEIGHT);
		setTitle("A Gui Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}

//the next few methods set up the three panels used for the demo GUI
	private void setMainContainer(){
		contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        JLabel theLabel = new JLabel("This is a label on the main content pane");
        contentPane.add(theLabel, BorderLayout.PAGE_START);
        contentPane.add(firstPanel(), BorderLayout.CENTER);
	}
/* this panel just holds the other panels.  We could have added 
them directly to the main container but I wanted to show you how you can nest containers*/
	private JPanel firstPanel(){
     	JPanel thePanel = new JPanel();
		thePanel.setLayout(new BoxLayout(thePanel, BoxLayout.PAGE_AXIS));
		JLabel l = new JLabel("Using Lambda Listeners");
		thePanel.add(l);
		thePanel.add(interactWithGamePanel());
		thePanel.add(userInputPanel());
		thePanel.setBorder(BorderFactory.createLineBorder(Color.RED)); //added a border so you could see the boundaries of the panel
	
		return thePanel;
	}
/* this panel contains a listener that interacts with my "game"
class.  The Game class is also known as the 'model' in OO design */
	private JPanel interactWithGamePanel(){
		JPanel gamePanel = new JPanel();
		gamePanel.setLayout(new FlowLayout());
		modelText = new TextField(myC.getStringVal());
		gamePanel.add(modelText);
		JButton modelButton = new JButton("set string value to dinosaur");
		modelButton.addActionListener(myListener->updateString("dinosaur"));
		gamePanel.add(modelButton);
		gamePanel.setBorder(BorderFactory.createLineBorder(Color.BLUE)); //added a border so you could see the boundaries of the panel
		return gamePanel;
	}

/* this panel contains a listener that interacts with the input from the user */
	private JPanel userInputPanel(){
		JPanel aPanel = new JPanel();
		aPanel.setLayout(new FlowLayout());
		JLabel showMe = new JLabel("your text will show up here");
		aPanel.add(showMe);
		JTextField editMe = new JTextField("you can type text here");
		editMe.setColumns(15); //to keep it from reducing to a very small field when I hit enter
		editMe.addActionListener(ev->editFromUser(editMe, showMe));
		aPanel.add(editMe);
		aPanel.setBorder(BorderFactory.createLineBorder(Color.GREEN)); //added a border so you could see the boundaries of the panel

		return aPanel;

	}


/* an easy way to ensure single responsibility within a gui is to create a method that is called
by your listener.  It also makes your code tider.

In more advanced OO programs these controller methods and the main method would live in 
their own class (often referred to as a controller class)

You don't have to make a separate class but it would be a good idea to have the controller
methods separate from the setting up the gui methods.

*/
	private void editFromUser(JTextField field, JLabel output){
		String userIn = field.getText();
		output.setText(userIn);
		field.setText("");

	}

	private void updateNum(int val){
		System.out.println("in update method");
		myC.update(val, "");
	}

	private void updateString(String val){
		System.out.println("in string update");
		myC.update(0, val);
		modelText.setText(myC.getStringVal());
	}


	public static void main(String[] args)
	{
		NotAGame game = new NotAGame();
		ExampleGui thing = new ExampleGui(game);
		thing.setVisible(true);
	}
}